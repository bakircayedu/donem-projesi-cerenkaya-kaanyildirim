using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.entity;

namespace movieapp.data.Abstract
{
    public interface IFilmRepository : IRepository<Film>
    {
        Film GetMovieDetails(int id);
    }
}