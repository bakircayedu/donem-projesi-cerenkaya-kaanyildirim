using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.entity;

namespace movieapp.data.Abstract
{
    public interface IBiletDetaylari_KoltukRepository : IRepository<BiletDetaylariKoltuk>
    {
        BiletDetaylariKoltuk GetTheaterAndSeatId(int ticketDetailId,int SeatId);
        List<BiletDetaylariKoltuk> GetSeatStates(int id);
    }
}