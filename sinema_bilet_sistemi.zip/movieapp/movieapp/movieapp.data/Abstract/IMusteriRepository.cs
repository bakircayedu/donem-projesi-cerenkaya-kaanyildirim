using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.entity;

namespace movieapp.data.Abstract
{
    public interface IMusteriRepository : IRepository<Musteri>
    {
        Musteri MusteriKontrol(string isim, string soyisim, string eposta,
        string telefon);
    }
}