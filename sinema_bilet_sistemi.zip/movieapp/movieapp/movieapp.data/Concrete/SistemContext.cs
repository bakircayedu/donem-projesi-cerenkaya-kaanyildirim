﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public partial class SistemContext : DbContext
    {
        public SistemContext()
        {
        }

        public SistemContext(DbContextOptions<SistemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Bilet> Bilet { get; set; }
        public virtual DbSet<BiletDetaylari> BiletDetaylari { get; set; }
        public virtual DbSet<BiletDetaylariKoltuk> BiletDetaylariKoltuk { get; set; }
        public virtual DbSet<Film> Film { get; set; }
        public virtual DbSet<FilmTuru> FilmTuru { get; set; }
        public virtual DbSet<Izleyiciler> Izleyiciler { get; set; }
        public virtual DbSet<Koltuk> Koltuk { get; set; }
        public virtual DbSet<Musteri> Musteri { get; set; }
        public virtual DbSet<Salon> Salon { get; set; }
        public virtual DbSet<Seans> Seans { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=sinema_bilet_sistemi; Integrated Security=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Bilet>(entity =>
            {
                entity.Property(e => e.BiletId).ValueGeneratedNever();

                entity.Property(e => e.Fiyat).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.BiletDetaylari)
                    .WithMany(p => p.Bilet)
                    .HasForeignKey(d => d.BiletDetaylariId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Bilet_BiletDetaylari");

                entity.HasOne(d => d.Koltuk)
                    .WithMany(p => p.Bilet)
                    .HasForeignKey(d => d.KoltukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Bilet_Koltuk");

                entity.HasOne(d => d.Musteri)
                    .WithMany(p => p.Bilet)
                    .HasForeignKey(d => d.MusteriId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Bilet_Musteri");
            });

            modelBuilder.Entity<BiletDetaylari>(entity =>
            {
                entity.Property(e => e.BiletDetaylariId).ValueGeneratedNever();

                entity.Property(e => e.Tarih).HasColumnType("datetime");

                entity.HasOne(d => d.Film)
                    .WithMany(p => p.BiletDetaylari)
                    .HasForeignKey(d => d.FilmId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BiletDetaylari_Film");

                entity.HasOne(d => d.Salon)
                    .WithMany(p => p.BiletDetaylari)
                    .HasForeignKey(d => d.SalonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BiletDetaylari_Salon");

                entity.HasOne(d => d.Seans)
                    .WithMany(p => p.BiletDetaylari)
                    .HasForeignKey(d => d.SeansId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BiletDetaylari_Seans");
            });

            modelBuilder.Entity<BiletDetaylariKoltuk>(entity =>
            {
                entity.HasKey(e => new { e.BiletDetaylariId, e.KoltukId });

                entity.ToTable("BiletDetaylari_Koltuk");

                entity.HasOne(d => d.BiletDetaylari)
                    .WithMany(p => p.BiletDetaylariKoltuk)
                    .HasForeignKey(d => d.BiletDetaylariId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BiletDetaylari_Koltuk_BiletDetaylari");

                entity.HasOne(d => d.Koltuk)
                    .WithMany(p => p.BiletDetaylariKoltuk)
                    .HasForeignKey(d => d.KoltukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BiletDetaylari_Koltuk_Koltuk");
            });

            modelBuilder.Entity<Film>(entity =>
            {
                entity.Property(e => e.FilmId).ValueGeneratedNever();

                entity.Property(e => e.ArkaplanUrl)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Isim)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Oyuncular)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.PosterUrl)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Yonetmen)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.FilmTuru)
                    .WithMany(p => p.Film)
                    .HasForeignKey(d => d.FilmTuruId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Film_FilmTuru");
            });

            modelBuilder.Entity<FilmTuru>(entity =>
            {
                entity.Property(e => e.FilmTuruId).ValueGeneratedNever();

                entity.Property(e => e.Tur)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Izleyiciler>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Izleyiciler");

                entity.Property(e => e.FilmIsmi)
                    .IsRequired()
                    .HasColumnName("film_ismi")
                    .HasMaxLength(100);

                entity.Property(e => e.Isim)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Soyisim)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Koltuk>(entity =>
            {
                entity.Property(e => e.KoltukId).ValueGeneratedNever();

                entity.HasOne(d => d.Salon)
                    .WithMany(p => p.Koltuk)
                    .HasForeignKey(d => d.SalonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Koltuk_Salon");
            });

            modelBuilder.Entity<Musteri>(entity =>
            {
                entity.Property(e => e.MusteriId).ValueGeneratedNever();

                entity.Property(e => e.Eposta)
                    .IsRequired()
                    .HasColumnName("EPosta")
                    .HasMaxLength(100);

                entity.Property(e => e.Isim)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Soyisim)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.TelefonNum)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Salon>(entity =>
            {
                entity.Property(e => e.SalonId).ValueGeneratedNever();
            });

            modelBuilder.Entity<Seans>(entity =>
            {
                entity.Property(e => e.SeansId).ValueGeneratedNever();

                entity.Property(e => e.SeansSaati)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
