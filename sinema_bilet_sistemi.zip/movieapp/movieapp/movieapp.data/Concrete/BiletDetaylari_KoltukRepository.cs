using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class BiletDetaylari_KoltukRepository : GenericRepository<BiletDetaylariKoltuk, SistemContext>, IBiletDetaylari_KoltukRepository
    {
        public List<BiletDetaylariKoltuk> GetSeatStates(int id)
        {
            using(var context = new SistemContext())
            {
                return context.BiletDetaylariKoltuk
                                        .Where(i=> i.BiletDetaylari.FilmId == id)
                                        .Include(i => i.BiletDetaylari)
                                        .ThenInclude(i => i.Seans)
                                        .Include(i => i.Koltuk)
                                        .ToList(); 
                                                                              
            }
        }

        public BiletDetaylariKoltuk GetTheaterAndSeatId(int ticketDetailId,int seatId)
        {
            using(var context = new SistemContext())
            {
                return context.BiletDetaylariKoltuk
                                        .Where(i => i.BiletDetaylariId == ticketDetailId && i.KoltukId == seatId
                                        ).FirstOrDefault();                                          
            }
        }
    }
}