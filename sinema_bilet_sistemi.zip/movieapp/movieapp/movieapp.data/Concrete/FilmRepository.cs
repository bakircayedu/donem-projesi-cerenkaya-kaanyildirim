using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class FilmRepository : GenericRepository<Film, SistemContext>, IFilmRepository
    {
        public Film GetMovieDetails(int id)
        {
            using(var context = new SistemContext())
            {
                return context.Film
                                .Where(i => i.FilmId == id)
                                .Include(i => i.FilmTuru).FirstOrDefault();
            }
        }
    }
}