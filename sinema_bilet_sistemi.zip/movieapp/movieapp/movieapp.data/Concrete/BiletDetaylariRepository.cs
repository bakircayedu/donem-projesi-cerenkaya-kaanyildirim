using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class BiletDetaylariRepository : GenericRepository<BiletDetaylari, SistemContext>, IBiletDetaylariRepository
    {
        public List<BiletDetaylari> GetTicketDetails(int id)
        {
            var context = new SistemContext();                           
            return context.BiletDetaylari   
                            .Where(i => i.FilmId == id)
                            .Include(i=> i.BiletDetaylariKoltuk)
                            .Include(i => i.Film)
                            .Include(i => i.Salon)
                            .Include(i => i.Seans)
                            .ToList();                            
        }
    }
}