using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class BiletRepository : GenericRepository<Bilet, SistemContext>, IBiletRepository
    {
        public List<Bilet> GetTicketDetails(int id)
        {
            using(var context = new SistemContext())
            {
                return context.Bilet
                                .Where(i => i.MusteriId == id)
                                .Include(i => i.Koltuk)
                                .Include(i => i.BiletDetaylari)
                                .ThenInclude(i => i.Salon)
                                .Include(i => i.BiletDetaylari)
                                .ThenInclude(i => i.Seans)
                                .Include(i => i.BiletDetaylari)
                                .ThenInclude(i => i.Film)
                                .ToList();                               
            }
        }
    }
}