using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class MusteriRepository : GenericRepository<Musteri, SistemContext>, IMusteriRepository
    {
        public Musteri MusteriKontrol(string isim, string soyisim, string eposta, string telefon)
        {
            var context = new SistemContext();            
               
            return context.Musteri
                            .Include(i => i.Bilet)
                            .ThenInclude(i => i.BiletDetaylari)
                            .ThenInclude(i => i.Film)
                            .Where(i => i.Isim == isim && i.Soyisim == soyisim && i.Eposta == eposta && i.TelefonNum == telefon)
                            .SingleOrDefault();
        }
    }
}