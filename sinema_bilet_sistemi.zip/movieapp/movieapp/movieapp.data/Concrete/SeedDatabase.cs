using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using movieapp.entity;

namespace movieapp.data.Concrete
{
    public class SeedDatabase
    {
        public static void Seed()
        {
            var context= new SistemContext();            
            if(context.Database.GetPendingMigrations().Count() == 0)
            {
                if(context.FilmTuru.Count()== 0)
                {
                    context.FilmTuru.AddRange(turler);
                }     
                if(context.Film.Count()== 0)
                {
                    context.Film.AddRange(filmler);
                }      
                if(context.Musteri.Count()== 0)
                {
                    context.Musteri.AddRange(musteriler);
                }      
                if(context.Seans.Count()== 0)
                {
                    context.Seans.AddRange(seanslar);
                }
                if(context.Salon.Count()== 0)
                {
                    context.Salon.AddRange(salonlar);
                }
                if(context.Bilet.Count()== 0)
                {
                    context.Bilet.AddRange(biletler);
                }            
            }
            context.SaveChanges();
        }
        private static FilmTuru[] turler={
            new FilmTuru(){FilmTuruId= 1, Tur="Animasyon"},
            new FilmTuru(){FilmTuruId= 2, Tur="Aksiyon"},
            new FilmTuru(){FilmTuruId= 3, Tur="Suç"},
            new FilmTuru(){FilmTuruId= 4, Tur="Savaş"},
            new FilmTuru(){FilmTuruId= 5, Tur="Komedi"}
        };
        private static Film[] filmler ={
            new Film(){FilmId= 1, Isim= "Spider-Man: Into the Spider-Verse", FilmTuruId= 1, Sure= 116, PosterUrl="/Images/Posters/spiderman.jpg",ArkaplanUrl="/Images/background/spiderman.jpg", Yonetmen="Peter Ramsey", Oyuncular="Jake Johnson,Shameik Moore"},
            new Film(){FilmId= 2, Isim= "Tenet", FilmTuruId= 2,Sure= 150, PosterUrl="/Images/Posters/Tenet.jpg",ArkaplanUrl="/Images/Background/Tenet.jpg", Yonetmen="Christopher Nolan", Oyuncular="John David Washington, Robert Pattinson"},
            new Film(){FilmId= 3, Isim= "Drive", FilmTuruId= 3,Sure= 100, PosterUrl="/Images/Posters/drive.jpg",ArkaplanUrl="/Images/Background/drive.png", Yonetmen="Nicolas Winding Refn", Oyuncular="Ryan Gosling, Carey Mulligan"},
            new Film(){FilmId= 4, Isim= "1917"
            ,FilmTuruId= 4,Sure= 112, PosterUrl="/Images/Posters/1917.jpg",ArkaplanUrl="/Images/Background/1917.jpg", Yonetmen="Sam Mendes", Oyuncular="George MacKay, Richard Madden"},
            new Film(){FilmId= 5, Isim= "Superbad",FilmTuruId= 5,Sure= 119, PosterUrl="/Images/Posters/superbad.jpg",ArkaplanUrl="/Images/Background/superbad.jpg", Yonetmen="Greg Mottola",Oyuncular="Jonah Hill, Seth Rogen"},
        };
        private static Musteri[] musteriler ={
            new Musteri(){MusteriId= 1, Isim="Kaan", Soyisim="Yıldırım", Eposta="kaan@hotmail.com", TelefonNum="0 535 849 25 85"},
            new Musteri(){MusteriId= 2, Isim="Ceren", Soyisim="Kaya", Eposta="ceren@gmail.com", TelefonNum="0 537 459 21 36"}
        };

        private static Seans[] seanslar={
            new Seans(){ SeansId=1, SeansSaati= "12.00"},
            new Seans(){ SeansId=2, SeansSaati= "13.00"},
            new Seans(){ SeansId=3, SeansSaati= "14.00"},
            new Seans(){ SeansId=4, SeansSaati= "15.00"},
            new Seans(){ SeansId=5, SeansSaati= "16.00"},
        };
        private static Koltuk[] Koltuklar={
            new Koltuk(){ KoltukId=1, KoltukNo=1, SalonId = 1}
        };       
        private static Salon[] salonlar={
            new Salon(){ SalonId=1, SalonNo=1, KoltukSayisi=10},
            new Salon(){ SalonId=2, SalonNo=2, KoltukSayisi=10},
            new Salon(){ SalonId=3, SalonNo=3, KoltukSayisi=10},
            new Salon(){ SalonId=4, SalonNo=4, KoltukSayisi=10},
            new Salon(){ SalonId=5, SalonNo=5, KoltukSayisi=10}
        };
        private static Bilet[] biletler ={
            new Bilet(){ BiletId=1, MusteriId=1, BiletDetaylariId=1, KoltukId=9, Fiyat=32},
            new Bilet(){ BiletId=2, MusteriId=2, BiletDetaylariId=1, KoltukId=10,Fiyat=32}
        };
        private static BiletDetaylari[] biletDetaylari={
            new BiletDetaylari(){ BiletDetaylariId=1, FilmId=1, SeansId=1, SalonId=1, Tarih= new DateTime(2021,12,15)},
            new BiletDetaylari(){ BiletDetaylariId=2, FilmId=2, SeansId=2, SalonId=2, Tarih= new DateTime(2021,12,16)}
        };
        
    }
}