﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class BiletDetaylariKoltuk
    {
        public int BiletDetaylariId { get; set; }
        public int KoltukId { get; set; }
        public bool KoltukDoluMu { get; set; }

        public virtual BiletDetaylari BiletDetaylari { get; set; }
        public virtual Koltuk Koltuk { get; set; }
    }
}
