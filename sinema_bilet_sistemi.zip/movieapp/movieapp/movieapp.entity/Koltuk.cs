﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Koltuk
    {
        public Koltuk()
        {
            Bilet = new HashSet<Bilet>();
            BiletDetaylariKoltuk = new HashSet<BiletDetaylariKoltuk>();
        }

        public int KoltukId { get; set; }
        public int SalonId { get; set; }
        public int KoltukNo { get; set; }

        public virtual Salon Salon { get; set; }
        public virtual ICollection<Bilet> Bilet { get; set; }
        public virtual ICollection<BiletDetaylariKoltuk> BiletDetaylariKoltuk { get; set; }
    }
}
