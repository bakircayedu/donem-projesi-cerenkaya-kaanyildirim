﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Izleyiciler
    {
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public string FilmIsmi { get; set; }
    }
}
