﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Seans
    {
        public Seans()
        {
            BiletDetaylari = new HashSet<BiletDetaylari>();
        }

        public int SeansId { get; set; }
        public string SeansSaati { get; set; }

        public virtual ICollection<BiletDetaylari> BiletDetaylari { get; set; }
    }
}
