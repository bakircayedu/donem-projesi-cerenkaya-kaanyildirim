﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Film
    {
        public Film()
        {
            BiletDetaylari = new HashSet<BiletDetaylari>();
        }

        public int FilmId { get; set; }
        public string Isim { get; set; }
        public int Sure { get; set; }
        public string PosterUrl { get; set; }
        public string ArkaplanUrl { get; set; }
        public string Yonetmen { get; set; }
        public string Oyuncular { get; set; }
        public int FilmTuruId { get; set; }

        public virtual FilmTuru FilmTuru { get; set; }
        public virtual ICollection<BiletDetaylari> BiletDetaylari { get; set; }
    }
}
