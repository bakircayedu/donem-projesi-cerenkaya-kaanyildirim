﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Bilet
    {
        public int BiletId { get; set; }
        public int MusteriId { get; set; }
        public int KoltukId { get; set; }
        public decimal Fiyat { get; set; }
        public int BiletDetaylariId { get; set; }

        public virtual BiletDetaylari BiletDetaylari { get; set; }
        public virtual Koltuk Koltuk { get; set; }
        public virtual Musteri Musteri { get; set; }
    }
}
