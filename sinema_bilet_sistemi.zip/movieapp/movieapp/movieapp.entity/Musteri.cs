﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Musteri
    {
        public Musteri()
        {
            Bilet = new HashSet<Bilet>();
        }

        public int MusteriId { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public string TelefonNum { get; set; }
        public string Eposta { get; set; }
        public int BiletSayisi { get; set; }

        public virtual ICollection<Bilet> Bilet { get; set; }
    }
}
