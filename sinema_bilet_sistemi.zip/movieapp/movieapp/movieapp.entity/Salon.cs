﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class Salon
    {
        public Salon()
        {
            BiletDetaylari = new HashSet<BiletDetaylari>();
            Koltuk = new HashSet<Koltuk>();
        }

        public int SalonId { get; set; }
        public int SalonNo { get; set; }
        public int KoltukSayisi { get; set; }

        public virtual ICollection<BiletDetaylari> BiletDetaylari { get; set; }
        public virtual ICollection<Koltuk> Koltuk { get; set; }
    }
}
