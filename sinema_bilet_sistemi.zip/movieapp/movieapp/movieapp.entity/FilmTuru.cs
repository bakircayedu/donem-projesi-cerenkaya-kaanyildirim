﻿using System;
using System.Collections.Generic;

namespace movieapp.entity
{
    public partial class FilmTuru
    {
        public FilmTuru()
        {
            Film = new HashSet<Film>();
        }

        public int FilmTuruId { get; set; }
        public string Tur { get; set; }

        public virtual ICollection<Film> Film { get; set; }
    }
}
