using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.data;
using movieapp.entity;

namespace movieapp.business.Abstract
{
    public interface IBiletDetaylari_KoltukService
    {
        void Update(BiletDetaylariKoltuk entity);
        BiletDetaylariKoltuk GetTheaterAndSeatId(int ticketDetailId,int SeatId);
        List<BiletDetaylariKoltuk> GetSeatStates(int id);
    }
}