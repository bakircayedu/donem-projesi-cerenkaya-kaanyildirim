using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.data;
using movieapp.entity;

namespace movieapp.business.Abstract
{
    public interface IFilmService
    {
        Film GetById(int id);
        List<Film> GetAll();
        Film GetMovieDetails(int id);
    }
}