using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.data;
using movieapp.entity;

namespace movieapp.business.Abstract
{
    public interface IBiletService
    {
        Bilet GetById(int id);
        List<Bilet> GetAll();
        void Create(Bilet entity);
        void Delete(Bilet entity);
        List<Bilet> GetTicketDetails(int id);
    }
}