using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.data;
using movieapp.entity;

namespace movieapp.business.Abstract
{
    public interface IMusteriService
    {
        List<Musteri> GetAll();
        void Create(Musteri entity);
        void Update(Musteri entity);
        Musteri MusteriKontrol(string isim, string soyisim, string eposta,
        string telefon);
    }
}