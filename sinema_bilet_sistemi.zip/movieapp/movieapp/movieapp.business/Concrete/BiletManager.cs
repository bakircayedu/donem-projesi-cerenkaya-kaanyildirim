using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.business.Concrete
{
    public class BiletManager : IBiletService
    {
        private IBiletRepository _biletRepository;
        public BiletManager(IBiletRepository biletRepository)
        {
            _biletRepository = biletRepository;
        }
        public void Create(Bilet entity)
        {
            _biletRepository.Create(entity);
        }

        public void Delete(Bilet entity)
        {
            _biletRepository.Delete(entity);
        }

        public List<Bilet> GetAll()
        {
            return _biletRepository.GetAll();
        }

        public Bilet GetById(int id)
        {
            return _biletRepository.GetById(id);
        }

        public List<Bilet> GetTicketDetails(int id)
        {
            return _biletRepository.GetTicketDetails(id);
        }
    }
}