using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.business.Concrete
{
    public class BiletDetaylariManager : IBiletDetaylariService
    {
        private IBiletDetaylariRepository _biletDetaylariRepository;
        public BiletDetaylariManager(IBiletDetaylariRepository biletDetaylariRepository)
        {
            _biletDetaylariRepository = biletDetaylariRepository;
        }
        public List<BiletDetaylari> GetTicketDetails(int id)
        {
            return _biletDetaylariRepository.GetTicketDetails(id);
        }
    }
}