using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.business.Concrete
{
    public class FilmManager : IFilmService
    {
        private IFilmRepository _filmRepository;
        public FilmManager(IFilmRepository filmRepository)
        {
            _filmRepository = filmRepository;
        }


        public List<Film> GetAll()
        {
            return _filmRepository.GetAll();
        }

        public Film GetById(int id)
        {
            return _filmRepository.GetById(id);
        }

        public Film GetMovieDetails(int id)
        {
            return _filmRepository.GetMovieDetails(id);
        }


    }
}