using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.business.Concrete
{
    public class BiletDetaylari_KoltukManager : IBiletDetaylari_KoltukService
    {
        private IBiletDetaylari_KoltukRepository _biletDetaylari_KoltukRepository;
        public BiletDetaylari_KoltukManager(IBiletDetaylari_KoltukRepository biletDetaylari_KoltukRepository)
        {
            _biletDetaylari_KoltukRepository = biletDetaylari_KoltukRepository;
        }
        public void Update(BiletDetaylariKoltuk entity)
        {
            _biletDetaylari_KoltukRepository.Update(entity);
        }
        
        public BiletDetaylariKoltuk GetTheaterAndSeatId(int ticketDetailId,int SeatId)
        {
            return _biletDetaylari_KoltukRepository.GetTheaterAndSeatId(ticketDetailId,SeatId);
        }

        public List<BiletDetaylariKoltuk> GetSeatStates(int id)
        {
            return _biletDetaylari_KoltukRepository.GetSeatStates(id);
        }
    }
}