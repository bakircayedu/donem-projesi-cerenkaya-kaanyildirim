using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;

namespace movieapp.business.Concrete
{
    public class MusteriManager : IMusteriService
    {
        private IMusteriRepository _musteriRepository;
        public MusteriManager(IMusteriRepository musteriRepository)
        {
            _musteriRepository = musteriRepository;
        }
        public void Create(Musteri entity)
        {
            _musteriRepository.Create(entity);
        }
        public List<Musteri> GetAll()
        {
            return _musteriRepository.GetAll();
        }
        public Musteri MusteriKontrol(string isim, string soyisim, string eposta, string telefon)
        {
            return _musteriRepository.MusteriKontrol(isim, soyisim, eposta, telefon);
        }
        public void Update(Musteri entity)
        {
            _musteriRepository.Update(entity);
        }
    }
}