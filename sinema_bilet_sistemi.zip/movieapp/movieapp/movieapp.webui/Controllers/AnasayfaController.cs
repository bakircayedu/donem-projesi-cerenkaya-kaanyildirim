using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.entity;
using movieapp.webui.ViewModels;

namespace movieapp.webui.Controllers
{
    public class AnasayfaController : Controller
    {
        private IFilmService _filmService;
        public AnasayfaController(IFilmService filmService)
        {
            this._filmService = filmService;
        }
        public IActionResult Index()
        {               
            List<Film> Filmler = _filmService.GetAll();        
            return View(Filmler);
        }
    }
}