using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.entity;
using movieapp.webui.ViewModels;

namespace movieapp.webui.Controllers
{
    public class BiletController : Controller
    {
        private IFilmService _filmService;
        private IMusteriService _musteriService;
        private IBiletService _biletService;
        private IBiletDetaylari_KoltukService _biletDetaylari_KoltukService;
        private IBiletDetaylariService _biletDetaylariService;

        public BiletController(IFilmService filmService,IMusteriService musteriService , IBiletService biletService, IBiletDetaylari_KoltukService biletDetaylari_KoltukService, IBiletDetaylariService biletDetaylariService)
        {
            this._filmService = filmService;
            this._musteriService = musteriService;
            this._biletService = biletService;
            this._biletDetaylari_KoltukService = biletDetaylari_KoltukService;
            this._biletDetaylariService = biletDetaylariService;
        }
        
        [HttpGet]
        public IActionResult BiletAlim(int id)
        {
            TicketViewModel tvm = new TicketViewModel();
            //Film Detayları
            tvm.biletDetaylari=_biletDetaylariService.GetTicketDetails(id);         
            tvm.film = _filmService.GetById((int)id);            
            //Koltuk Durumları                      
            tvm.koltukDurumu= _biletDetaylari_KoltukService.GetSeatStates(id);      
            return View(tvm);
        }
        
        [HttpPost]
        public IActionResult BiletAlim(TicketViewModel ticket,int id)
        {   
            TicketViewModel tvm = new TicketViewModel();
            tvm.biletDetaylari=_biletDetaylariService.GetTicketDetails(id); 
            var biletEntity = new Bilet();       

            //Müşteri Ekleme
            var musteriEntity = new Musteri();
            if(_musteriService.MusteriKontrol(ticket.musteri.Isim, ticket.musteri.Soyisim, ticket.musteri.Eposta, ticket.musteri.TelefonNum) == null)
            {                               
                musteriEntity.MusteriId = _musteriService.GetAll().LastOrDefault().MusteriId + 1 ;
                biletEntity.MusteriId = _musteriService.GetAll().LastOrDefault().MusteriId + 1;
                musteriEntity.Isim = ticket.musteri.Isim;
                musteriEntity.Soyisim= ticket.musteri.Soyisim;
                musteriEntity.Eposta = ticket.musteri.Eposta;
                musteriEntity.TelefonNum = ticket.musteri.TelefonNum;            
                _musteriService.Create(musteriEntity);
            }
            else
            {
                musteriEntity = _musteriService.MusteriKontrol(ticket.musteri.Isim, ticket.musteri.Soyisim, ticket.musteri.Eposta, ticket.musteri.TelefonNum);
                biletEntity.MusteriId = musteriEntity.MusteriId;
                _musteriService.Update(musteriEntity);
            }

            //Bilet Ekleme        
            biletEntity.BiletId = _biletService.GetAll().LastOrDefault().BiletId +1;      
            biletEntity.KoltukId = ticket.bilet.KoltukId;
            biletEntity.Fiyat = 32;     
        
            //Güncelenecek olan koltuğun seansı ve tarihi kontrol ediliyor
            foreach (var item in tvm.biletDetaylari)
            {
                if (item.Seans.SeansSaati == ticket.biletDetaylariActive.Seans.SeansSaati)
                {
                    if (item.Tarih == ticket.biletDetaylariActive.Tarih)
                    {
                        biletEntity.BiletDetaylariId = item.BiletDetaylariId;
                        //Koltuk Durumu Güncelleme
                        var koltukEntity = _biletDetaylari_KoltukService.GetTheaterAndSeatId(item.BiletDetaylariId,ticket.bilet.KoltukId);
                        koltukEntity.KoltukDoluMu = true;                    
                        _biletDetaylari_KoltukService.Update(koltukEntity);
                    }
                }
            }
            _biletService.Create(biletEntity);
                                   
            return RedirectToAction("Index","Anasayfa");
        }
        [HttpGet]
        public IActionResult Biletİade()
        {
            BiletIadeViewModel bilet = new BiletIadeViewModel();
            return View(bilet);
        }
        [HttpPost]
        public IActionResult Biletİade(BiletIadeViewModel biletim)
        {
            BiletIadeViewModel bilet = new BiletIadeViewModel();
            if(_musteriService.MusteriKontrol(biletim.bilet.Musteri.Isim, biletim.bilet.Musteri.Soyisim, biletim.bilet.Musteri.Eposta, biletim.bilet.Musteri.TelefonNum) != null)
            {
                Musteri musteri = _musteriService.MusteriKontrol(biletim.bilet.Musteri.Isim, biletim.bilet.Musteri.Soyisim, biletim.bilet.Musteri.Eposta, biletim.bilet.Musteri.TelefonNum);
                List<Bilet> musteriBiletleri = _biletService.GetTicketDetails(musteri.MusteriId).DefaultIfEmpty().ToList();
                bilet.biletler = musteriBiletleri;               
            }
            return View(bilet);            
        }
        [HttpPost]
        public IActionResult Iade(int biletId, int koltukId, int biletDetayId)
        {
            //Bilet Silme
            Bilet iadeBilet =_biletService.GetById(biletId);
            _biletService.Delete(iadeBilet);

            //Koltuk Güncelleme
            BiletDetaylariKoltuk iadeKoltuk = _biletDetaylari_KoltukService.GetTheaterAndSeatId(biletDetayId,koltukId);
            iadeKoltuk.KoltukDoluMu = false;
            _biletDetaylari_KoltukService.Update(iadeKoltuk);
            
            return RedirectToAction("Index","Anasayfa");           
        }
    }
}