using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using movieapp.business.Abstract;
using movieapp.data;
using movieapp.data.Concrete;
using movieapp.entity;
using movieapp.webui.ViewModels;

namespace movieapp.webui.Controllers
{
    public class FilmController : Controller
    {
        private IFilmService _filmService;
        
        public FilmController(IFilmService filmService)
        {
            this._filmService = filmService;
        }
        public IActionResult Filmler()
        {   
            List<Film> Filmler = _filmService.GetAll();
            return View(Filmler);
        }
        public IActionResult FilmDetaylari(int? id)
        {         
            Film film = _filmService.GetMovieDetails((int)id);
            return View(film);            
        }

        public IActionResult IzleyicileriGoruntule()
        {   
            var context = new SistemContext();
            var izleyiciViewModel = new IzleyicilerViewModel();
            izleyiciViewModel.musteriler = context.Musteri.FromSqlRaw("exec FazlaBiletAlanMusteriler").ToList();         
            izleyiciViewModel.izleyiciler = context.Izleyiciler.ToList();
            return View(izleyiciViewModel);            
        }
    }
}