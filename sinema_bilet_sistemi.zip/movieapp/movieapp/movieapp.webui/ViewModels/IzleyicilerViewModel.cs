using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.entity;

namespace movieapp.webui.ViewModels
{
    public class IzleyicilerViewModel
    {
        public IzleyicilerViewModel()
        {
            izleyiciler = new List<Izleyiciler>();
            musteriler = new List<Musteri>();
        }
        public List<Izleyiciler> izleyiciler { get; set; }
        public List<Musteri> musteriler { get; set; }
    }
}