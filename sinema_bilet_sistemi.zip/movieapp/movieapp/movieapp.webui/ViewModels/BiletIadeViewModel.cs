using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using movieapp.data;
using movieapp.entity;

namespace movieapp.webui.ViewModels
{
    public class BiletIadeViewModel
    {
        public BiletIadeViewModel()
        {
            biletler = new List<Bilet>();
        }

        public Bilet bilet { get; set; }
        public List<Bilet> biletler { get; set; }
    }
}