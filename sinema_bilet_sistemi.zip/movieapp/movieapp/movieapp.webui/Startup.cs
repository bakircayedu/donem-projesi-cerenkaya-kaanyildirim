using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using movieapp.business.Abstract;
using movieapp.business.Concrete;
using movieapp.data;
using movieapp.data.Abstract;
using movieapp.data.Concrete;

namespace movieapp.webui
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<IFilmRepository, FilmRepository>();
            services.AddScoped<IMusteriRepository, MusteriRepository>();
            services.AddScoped<IBiletRepository, BiletRepository>();
            services.AddScoped<IBiletDetaylariRepository, BiletDetaylariRepository>();
            services.AddScoped<IBiletDetaylari_KoltukRepository, BiletDetaylari_KoltukRepository>();

            services.AddScoped<IFilmService, FilmManager>();           
            services.AddScoped<IMusteriService, MusteriManager>();          
            services.AddScoped<IBiletService, BiletManager>();
            services.AddScoped<IBiletDetaylariService, BiletDetaylariManager>();
            services.AddScoped<IBiletDetaylari_KoltukService, BiletDetaylari_KoltukManager>();
                      
            services.AddControllersWithViews();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                SeedDatabase.Seed();
                app.UseDeveloperExceptionPage();
                app.UseStaticFiles();
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern:"{controller=Anasayfa}/{action=Index}/{id?}"
                );
            });
        }
    }
}
